import { Component } from '@angular/core';

@Component({
  selector: 'app-task-form-component',
  standalone: true,
  imports: [],
  templateUrl: './task-form-component.component.html',
  styleUrl: './task-form-component.component.css'
})
export class TaskFormComponentComponent {
  title = 'form'
}
