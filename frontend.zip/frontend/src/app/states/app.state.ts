import { TaskState } from "./task/task.reducer";

export interface AppState {
  task: TaskState,
}
